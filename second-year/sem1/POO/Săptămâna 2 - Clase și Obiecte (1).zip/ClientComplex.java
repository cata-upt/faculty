class Complex{
  private double real, imaginar;
  private static int nrAfisari=0;
  public Complex(double r, double i){
      real=r;
      imaginar=i;
  }
  
  public double Modul(){
      double modul;
      double re=real*real;
      double img=imaginar*imaginar;
      return modul=Math.sqrt(re+img);
  }
  
  public void Afiseaza(){
      nrAfisari++;
      System.out.println(real+"+"+"i"+"*"+imaginar);
  }
  
  public Complex Suma(Complex c){
      Complex sum;
      double re=real+c.real;
      double img=imaginar+c.imaginar;
      sum=new Complex(re,img);  
      return sum;
  }
  
  public static int GetNrAfisari(){
      return nrAfisari;
  }
}

class ClientComplex{
    public static void main(String args[]){
    Complex complex;
    complex= new Complex(10,10);
    complex.Afiseaza();
    System.out.println(complex.Modul());
    Complex c2;
    c2=new Complex(4,4);
    Complex suma=complex.Suma(c2);
    suma.Afiseaza();
    System.out.println(Complex.GetNrAfisari());
    }
}